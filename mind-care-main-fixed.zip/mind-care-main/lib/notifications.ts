// Lightweight in-app reminder notifications using the browser's Notification
// API. This only fires while this tab is open — there's no push
// infrastructure (a service worker + VAPID keys + a push server) wired up
// for this project, so it can't wake a closed browser or a locked phone.
// Treat this as "a gentle nudge while using the app", not a substitute for
// a real push/SMS service — see CHANGELOG.md for that extension point.

export type SimpleReminder = { id: string; title: string; time: string }

function parseTimeLabel(label: string): { hour: number; minute: number } | null {
  const match = label.trim().match(/^(\d{1,2}):(\d{2})\s*(AM|PM)?$/i)
  if (!match) return null // e.g. "Every 2 hours" isn't a fixed clock time — nothing to schedule
  let hour = parseInt(match[1], 10)
  const minute = parseInt(match[2], 10)
  const meridiem = match[3]?.toUpperCase()
  if (meridiem === "PM" && hour !== 12) hour += 12
  if (meridiem === "AM" && hour === 12) hour = 0
  if (hour > 23 || minute > 59) return null
  return { hour, minute }
}

export function notificationsSupported(): boolean {
  return typeof window !== "undefined" && "Notification" in window
}

export function notificationPermission(): NotificationPermission | "unsupported" {
  if (!notificationsSupported()) return "unsupported"
  return Notification.permission
}

/** Call this from a direct user gesture (e.g. a toggle's onChange) — browsers may ignore the prompt otherwise. */
export async function requestNotificationPermission(): Promise<NotificationPermission | "unsupported"> {
  if (!notificationsSupported()) return "unsupported"
  if (Notification.permission === "default") return Notification.requestPermission()
  return Notification.permission
}

/** A short two-tone chime synthesized with the Web Audio API — no audio asset file needed. */
export function playChime() {
  try {
    const AudioContextCtor = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext
    if (!AudioContextCtor) return
    const ctx = new AudioContextCtor()
    const oscillator = ctx.createOscillator()
    const gain = ctx.createGain()
    oscillator.type = "sine"
    oscillator.frequency.setValueAtTime(660, ctx.currentTime)
    oscillator.frequency.setValueAtTime(880, ctx.currentTime + 0.15)
    gain.gain.setValueAtTime(0.15, ctx.currentTime)
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4)
    oscillator.connect(gain)
    gain.connect(ctx.destination)
    oscillator.start()
    oscillator.stop(ctx.currentTime + 0.4)
  } catch {
    /* sound is a nice-to-have — never let it break anything */
  }
}

/**
 * Schedules a browser Notification for each reminder whose clock time is
 * still ahead today (and a chime alongside it, if `sound` is on). Returns a
 * cleanup function that cancels every pending timer — call it on unmount or
 * whenever the reminder list / preferences change, to avoid double-firing.
 */
export function scheduleLocalReminders(reminders: SimpleReminder[], options: { sound: boolean }): () => void {
  if (!notificationsSupported() || Notification.permission !== "granted") return () => {}

  const timers: ReturnType<typeof setTimeout>[] = []
  const now = new Date()

  for (const reminder of reminders) {
    const parsed = parseTimeLabel(reminder.time)
    if (!parsed) continue

    const when = new Date(now)
    when.setHours(parsed.hour, parsed.minute, 0, 0)
    const delay = when.getTime() - now.getTime()
    if (delay <= 0 || delay > 24 * 60 * 60 * 1000) continue // already passed today, or unreasonably far off

    timers.push(
      setTimeout(() => {
        try {
          new Notification(reminder.title, { body: `Scheduled for ${reminder.time}`, tag: reminder.id })
        } catch {
          /* Notification constructor can throw in a few mobile/embedded contexts — never let it crash the app */
        }
        if (options.sound) playChime()
      }, delay),
    )
  }

  return () => timers.forEach(clearTimeout)
}
