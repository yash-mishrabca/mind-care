// Centralized, safe LocalStorage access.
// Every persisted value in MindCare goes through this file so that storage keys
// and failure handling live in exactly one place.

export const STORAGE_KEYS = {
  userRole: "mindcare:userRole",
  userName: "mindcare:userName",
  token: "mindcare:token",
  language: "mindcare:language",
  preferences: "mindcare:userPreferences",
  gameResults: "mindcare:gameResults",
  chatHistory: "mindcare:chatHistory",
  wellness: "mindcare:wellness",
} as const

export function storageAvailable(): boolean {
  try {
    if (typeof window === "undefined") return false
    const probe = "__mindcare_probe__"
    window.localStorage.setItem(probe, "1")
    window.localStorage.removeItem(probe)
    return true
  } catch {
    return false
  }
}

export function readValue<T>(key: string, fallback: T): T {
  try {
    if (typeof window === "undefined") return fallback
    const raw = window.localStorage.getItem(key)
    if (raw === null) return fallback
    return JSON.parse(raw) as T
  } catch {
    return fallback
  }
}

export function writeValue<T>(key: string, value: T): void {
  try {
    if (typeof window === "undefined") return
    window.localStorage.setItem(key, JSON.stringify(value))
  } catch {
    // Storage may be unavailable (private mode / quota). The app keeps working
    // with in-memory state only.
  }
}

export function removeValue(key: string): void {
  try {
    if (typeof window === "undefined") return
    window.localStorage.removeItem(key)
  } catch {
    /* no-op */
  }
}

/**
 * Clears every locally-cached value that's specific to a signed-in account
 * (display name, sharing/theme preferences, the offline game-result and
 * chat-history fallback caches). Call this on logout.
 *
 * Without this, a second person signing in on the same shared/kiosk device
 * could inherit the previous person's cached data — most concretely, their
 * offline-fallback game scores and assistant chat history — any time the
 * backend was briefly unreachable. The JWT itself is cleared separately by
 * clearToken() in lib/api.ts. `language` is intentionally left alone: it's
 * treated as a device-level display setting, not an account secret.
 */
export function clearAccountScopedLocalData(): void {
  removeValue(STORAGE_KEYS.userName)
  removeValue(STORAGE_KEYS.preferences)
  removeValue(STORAGE_KEYS.gameResults)
  removeValue(STORAGE_KEYS.chatHistory)
  removeValue(STORAGE_KEYS.wellness)
}

/* ------------------------------ Game results ------------------------------ */

export type GameId = "card-match" | "pattern-recall" | "word-recall" | "sequence-memory"

export type GameResult = {
  id: string
  game: GameId
  score: number
  accuracy: number
  durationSeconds: number
  playedAt: string // ISO date
}

export function getGameResults(): GameResult[] {
  return readValue<GameResult[]>(STORAGE_KEYS.gameResults, [])
}

/** A collision-resistant id for offline-fallback records (crypto.randomUUID when available). */
function localRecordId(prefix: string): string {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return `${prefix}-${crypto.randomUUID()}`
  }
  // Very old browsers without crypto.randomUUID: timestamp + random suffix
  // still collides far less often than timestamp alone.
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`
}

export function saveGameResultLocal(result: Omit<GameResult, "id" | "playedAt">): GameResult {
  const entry: GameResult = {
    ...result,
    id: localRecordId(result.game),
    playedAt: new Date().toISOString(),
  }
  const all = [entry, ...getGameResults()].slice(0, 200)
  writeValue(STORAGE_KEYS.gameResults, all)
  return entry
}

export function personalBest(game: GameId): number {
  return getGameResults()
    .filter((r) => r.game === game)
    .reduce((max, r) => Math.max(max, r.score), 0)
}
