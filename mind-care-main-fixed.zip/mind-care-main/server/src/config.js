require("dotenv").config()

const config = {
  port: process.env.PORT || 4000,
  jwtSecret: process.env.JWT_SECRET || "dev-secret-change-me",
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || "30d",
  corsOrigin: process.env.CORS_ORIGIN || "*",
  mongoUri: process.env.MONGODB_URI || "mongodb://127.0.0.1:27017/mindcare",
  // SECURITY: with no email service wired up, /auth/forgot-password used to
  // always return the raw reset token in the response so the demo UI could
  // link straight to the reset page. That means anyone who knows a user's
  // email could take over their account with no access to their inbox.
  // This now defaults to OFF outside development, and can be forced off
  // even in development with EXPOSE_DEV_RESET_TOKEN=false.
  exposeDevResetToken:
    process.env.EXPOSE_DEV_RESET_TOKEN != null
      ? process.env.EXPOSE_DEV_RESET_TOKEN === "true"
      : process.env.NODE_ENV !== "production",
}

if (process.env.NODE_ENV === "production" && config.jwtSecret === "dev-secret-change-me") {
  console.warn("[config] WARNING: JWT_SECRET is not set. Set a real secret before deploying to production.")
}

module.exports = config
