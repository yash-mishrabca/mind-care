const mongoose = require("mongoose")

const patientProfileSchema = new mongoose.Schema(
  {
    _id: { type: String, required: true }, // same as the user's id (1:1)
    age: { type: Number, default: null },
    condition: { type: String, default: "Memory & cognitive care plan" },
    careSince: { type: String, required: true },
    cognitiveScoreBase: { type: Number, default: 70 },
    inviteCode: { type: String, unique: true, sparse: true },
    // Real contact number so a caregiver's "Call" button dials someone real
    // instead of a placeholder. Optional — patients can add it in Settings.
    phone: { type: String, default: null },
    // Minutes offset from UTC (e.g. +330 for India Standard Time). Used so
    // alertService can reason about "afternoon" / "missed at 8pm" in the
    // patient's own local time instead of the server's UTC clock. Defaults
    // to IST since that's this app's primary audience; the frontend updates
    // it automatically from the browser on first load.
    timezoneOffsetMinutes: { type: Number, default: 330 },
  },
  { _id: false },
)

module.exports = mongoose.model("PatientProfile", patientProfileSchema)
