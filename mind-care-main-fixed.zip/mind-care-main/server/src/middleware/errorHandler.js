const { ApiError } = require("../utils/ApiError")

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  if (err instanceof ApiError) {
    return res.status(err.status).json({ error: { message: err.message, details: err.details ?? null } })
  }

  // A malformed :id / :activityId path param (e.g. "abc" instead of a real
  // ObjectId) used to fall through to the generic 500 below. Treat it as a
  // client error instead.
  if (err.name === "CastError") {
    return res.status(400).json({ error: { message: `Invalid id: ${err.value}` } })
  }

  // Mongoose schema validation failures (e.g. an enum field given a bad value).
  if (err.name === "ValidationError") {
    const message = Object.values(err.errors || {})
      .map((e) => e.message)
      .join(" ") || "Validation failed."
    return res.status(400).json({ error: { message } })
  }

  // Duplicate key (e.g. two near-simultaneous requests both trying to create
  // the same unique document, such as one day's wellness log).
  if (err.code === 11000) {
    return res.status(409).json({ error: { message: "That record already exists." } })
  }

  // eslint-disable-next-line no-console
  console.error(err)
  res.status(500).json({ error: { message: "Something went wrong on our end." } })
}

function notFoundHandler(req, res) {
  res.status(404).json({ error: { message: `No route for ${req.method} ${req.originalUrl}` } })
}

module.exports = { errorHandler, notFoundHandler }
