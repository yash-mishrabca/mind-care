// Server-side port of the frontend's `lib/assistant.ts`. Rule-based and
// grounded in real stored data by default (no external API needed). If the
// operator sets ANTHROPIC_API_KEY, llmService is tried first and this rule
// engine becomes the fallback for when that call is unavailable or fails.

const Reminder = require("../models/Reminder")
const WellnessLog = require("../models/WellnessLog")
const GameResult = require("../models/GameResult")
const Preferences = require("../models/Preferences")
const { getPatientProfile, findLinkedPatient } = require("./profileService")
const { gameNames } = require("../data/gamesCatalog")
const { todayKey, weekdayLong, dayStart } = require("../utils/dates")
const llmService = require("./llmService")

async function subjectPatientFor(user) {
  if (user.role === "patient") return user
  return findLinkedPatient(user.id)
}

async function getReminders(userId) {
  return Reminder.find({ userId }).sort({ sortOrder: 1 }).lean()
}

async function getTodayWellness(userId) {
  return WellnessLog.findOne({ userId, date: todayKey() }).lean()
}

async function getLatestResult(userId) {
  return GameResult.findOne({ userId }).sort({ playedAt: -1 }).lean()
}

/** The language the person actually typing to the assistant reads — the requester's own preference, not necessarily the patient's. */
async function getRequesterLanguage(userId) {
  const prefs = await Preferences.findById(userId).lean()
  return prefs?.language || "en"
}

async function buildContext(user) {
  const subject = await subjectPatientFor(user)
  if (!subject) return null

  const subjectId = subject.id || subject._id
  const profile = await getPatientProfile(subjectId)
  const reminders = await getReminders(subjectId)
  const wellness = await getTodayWellness(subjectId)
  const latest = await getLatestResult(subjectId)
  const language = await getRequesterLanguage(user.id)

  return {
    isSelf: subjectId === user.id,
    subjectFirstName: profile.firstName,
    profile,
    reminders,
    wellness,
    latest,
    language,
  }
}

/** "you" for the patient talking about themself, or their name for a caregiver. */
function subjectWord(ctx) {
  return ctx.isSelf ? "You" : ctx.subjectFirstName
}
function subjectWordLower(ctx) {
  return ctx.isSelf ? "you" : ctx.subjectFirstName
}
function possessive(ctx) {
  return ctx.isSelf ? "your" : `${ctx.subjectFirstName}'s`
}
function areIs(ctx) {
  return ctx.isSelf ? "are" : "is"
}
const isHi = (ctx) => ctx.language === "hi"

const GAME_LIST_EN = "Card Match, Pattern Recall, Word Recall, or Sequence Memory"
const GAME_LIST_HI = "कार्ड मैच, पैटर्न रीकॉल, वर्ड रीकॉल, या सीक्वेंस मेमोरी"

const rules = [
  {
    match: /\b(hello|hi|hey|good morning|good evening|namaste)\b/i,
    reply: (ctx) => {
      if (isHi(ctx)) {
        return ctx.isSelf
          ? `नमस्ते ${ctx.subjectFirstName}। आपको देखकर अच्छा लगा। क्या आप आज की गतिविधि शुरू करना चाहेंगे?`
          : `नमस्ते। ${ctx.subjectFirstName} ने हाल ही में चेक-इन किया है। क्या आप उनकी प्रगति के बारे में जानना चाहेंगे?`
      }
      return ctx.isSelf
        ? `Hello ${ctx.subjectFirstName}. It is good to see you. Would you like to start today's activity?`
        : `Hello. ${ctx.subjectFirstName} last checked in recently. Would you like an update on their progress?`
    },
  },
  {
    match: /\b(game|play|puzzle|exercise|activity)\b/i,
    reply: (ctx) => {
      if (isHi(ctx)) {
        if (!ctx.latest) {
          return `${ctx.isSelf ? "आप" : ctx.subjectFirstName} आज ${GAME_LIST_HI} खेल सकते हैं। कार्ड मैच शुरू करने के लिए सबसे आसान है - इसमें लगभग पांच मिनट लगते हैं।`
        }
        return `पिछली बार ${ctx.isSelf ? "आपने" : ctx.subjectFirstName + " ने"} ${gameNames[ctx.latest.game]} खेला और ${ctx.latest.accuracy}% सटीकता के साथ ${ctx.latest.score} अंक प्राप्त किए। बहुत बढ़िया। ${GAME_LIST_HI} सभी तैयार हैं।`
      }
      if (!ctx.latest) {
        return `${subjectWord(ctx)} can try ${GAME_LIST_EN} today. Card Match is the gentlest place to begin - it takes about five minutes.`
      }
      return `Last time, ${subjectWordLower(ctx)} played ${gameNames[ctx.latest.game]} and scored ${ctx.latest.score} points with ${ctx.latest.accuracy}% accuracy. Nice work. ${GAME_LIST_EN} are all ready when ${ctx.isSelf ? "you are" : "needed"}.`
    },
  },
  {
    match: /\b(week|progress|doing|score|improv|better)\b/i,
    reply: (ctx) => {
      if (isHi(ctx)) {
        const trend = ctx.profile.weeklyChange >= 0 ? "ऊपर" : "नीचे"
        return `${ctx.isSelf ? "आपका" : ctx.subjectFirstName + " का"} कॉग्निटिव स्कोर 100 में से ${ctx.profile.cognitiveScore} है, जो पिछले सप्ताह की तुलना में ${Math.abs(ctx.profile.weeklyChange)}% ${trend} है। औसत सटीकता लगभग ${ctx.profile.accuracy}% है और ${ctx.profile.streak} दिन की स्ट्रीक चल रही है।`
      }
      return `${possessive(ctx)[0].toUpperCase()}${possessive(ctx).slice(1)} cognitive score is ${ctx.profile.cognitiveScore} out of 100, which is ${ctx.profile.weeklyChange >= 0 ? "up" : "down"} ${Math.abs(ctx.profile.weeklyChange)}% vs last week. ${subjectWord(ctx)} ${areIs(ctx)} averaging around ${ctx.profile.accuracy}% accuracy and ${ctx.isSelf ? "are" : "is"} on a ${ctx.profile.streak} day streak.`
    },
  },
  {
    match: /\b(remind|routine|schedule|medicine|medication|pill)\b/i,
    reply: (ctx) => {
      if (isHi(ctx)) {
        if (ctx.reminders.length === 0) return "अभी तक कोई रिमाइंडर सेट नहीं किया गया है।"
        const list = ctx.reminders.map((r) => `${r.title} - ${r.timeLabel}`).join(", ")
        return `यह रही ${ctx.isSelf ? "आपकी" : ctx.subjectFirstName + " की"} दिनचर्या: ${list}। मैं इसे सरल रखूंगा और एक-एक करके याद दिलाऊंगा।`
      }
      if (ctx.reminders.length === 0) return "There are no reminders set up yet."
      const list = ctx.reminders.map((r) => `${r.title} at ${r.timeLabel}`).join(", ")
      return `Here is ${possessive(ctx)} routine: ${list}. I will keep it simple and remind ${ctx.isSelf ? "you" : "them"} one thing at a time.`
    },
  },
  {
    match: /\b(water|drink|thirsty|hydrate)\b/i,
    reply: (ctx) => {
      const glasses = ctx.wellness ? ctx.wellness.waterGlasses : 0
      const goal = ctx.wellness ? ctx.wellness.waterGoal : 8
      const remaining = Math.max(0, goal - glasses)
      if (isHi(ctx)) {
        return `${ctx.isSelf ? "आपने" : ctx.subjectFirstName + " ने"} आज ${glasses} गिलास पानी पिया है। ${remaining} और गिलास बेहतर होंगे। क्या एक घंटे में याद दिलाऊं?`
      }
      return `${subjectWord(ctx)} ${areIs(ctx)} had ${glasses} glasses of water today. ${remaining} more would be perfect. Would you like a reminder in an hour?`
    },
  },
  {
    match: /\b(sleep|tired|rest|nap)\b/i,
    reply: (ctx) => {
      const hours = ctx.wellness ? ctx.wellness.sleepHours : 7.5
      if (isHi(ctx)) {
        return `${ctx.isSelf ? "आप" : ctx.subjectFirstName} पिछली रात लगभग ${hours} घंटे सोए, जो स्वस्थ है। अगर थकान महसूस हो, तो थोड़ा आराम बिल्कुल ठीक है।`
      }
      return `${subjectWord(ctx)} slept about ${hours} hours last night, which is healthy. If ${ctx.isSelf ? "you feel" : "they feel"} tired, a short rest is absolutely fine.`
    },
  },
  {
    match: /\b(sad|lonely|worried|anxious|upset|scared|confus)\b/i,
    reply: (ctx) => {
      if (isHi(ctx)) {
        return `मुझे बताने के लिए धन्यवाद। ये भावनाएं सामान्य हैं और ${ctx.isSelf ? "आप" : "वे"} अकेले नहीं हैं। धीरे से सांस लें।${ctx.isSelf ? " क्या मैं आपके देखभालकर्ता को सूचित करूं?" : ""}`
      }
      return `Thank you for telling me. Those feelings are normal and ${ctx.isSelf ? "you are" : "they are"} not alone. Try a slow breath in, and a slow breath out.${ctx.isSelf ? " Would you like me to notify your caregiver?" : ""}`
    },
  },
  {
    match: /\b(who am i|my name|where am i|what day)\b/i,
    reply: (ctx) => {
      const today = weekdayLong(dayStart(0))
      if (isHi(ctx)) {
        return ctx.isSelf
          ? `आप ${ctx.profile.name} हैं, आपकी उम्र ${ctx.profile.age ?? "अज्ञात"} वर्ष है, और आप घर पर सुरक्षित हैं। आज ${today} है।`
          : `${ctx.profile.name} की उम्र ${ctx.profile.age ?? "अज्ञात"} वर्ष है। आज ${today} है।`
      }
      if (ctx.isSelf) {
        return `You are ${ctx.profile.name}, you are ${ctx.profile.age ?? "unknown"} years old, and you are safe at home. Today is ${today}.`
      }
      return `${ctx.profile.name} is ${ctx.profile.age ?? "unknown"} years old. Today is ${today}.`
    },
  },
  {
    match: /\b(caregiver|daughter|family|call)\b/i,
    reply: (ctx) => {
      if (isHi(ctx)) {
        return ctx.profile.caregiver
          ? `${ctx.profile.caregiver} ${ctx.isSelf ? "आपके" : "उनके"} देखभालकर्ता हैं और प्रगति देख सकते हैं। ${ctx.isSelf ? "वे" : "आप"} एक फोन कॉल की दूरी पर हैं।`
          : "अभी तक कोई देखभालकर्ता इस खाते से जुड़ा नहीं है।"
      }
      return ctx.profile.caregiver
        ? `${ctx.profile.caregiver} is ${ctx.isSelf ? "your" : "the"} caregiver and can see ${ctx.isSelf ? "your" : "their"} progress. ${ctx.isSelf ? "They are" : "You are"} only a phone call away whenever needed.`
        : "No caregiver is linked to this account yet."
    },
  },
  {
    match: /\b(sos|emergency|help me|urgent|danger)\b/i,
    reply: (ctx) =>
      isHi(ctx)
        ? "अगर यह आपात स्थिति है, तो कृपया ऐप में SOS बटन दबाएं या सीधे अपने देखभालकर्ता को कॉल करें। मैं यहां हूं, लेकिन तुरंत मदद के लिए वह तेज़ तरीका है।"
        : "If this is an emergency, please press the SOS button in the app or call your caregiver directly. I'm here, but that's the fastest way to get real help right now.",
  },
  {
    match: /\b(thank|thanks|great|good job|nice)\b/i,
    reply: (ctx) => (isHi(ctx) ? "आपका बहुत स्वागत है। जब भी जरूरत हो, मैं यहां हूं।" : "You are very welcome. I am here whenever you need me."),
  },
  {
    match: /\b(help|what can you do|options)\b/i,
    reply: (ctx) =>
      isHi(ctx)
        ? "मैं एक गतिविधि सुझा सकता हूं, सप्ताह की प्रगति बता सकता हूं, दिनचर्या पढ़ सकता हूं, या किसी मेमोरी गेम की ओर इशारा कर सकता हूं। बस अपने शब्दों में पूछें।"
        : "I can suggest an activity, share how the week is going, read out the daily routine, or point you to a memory game. Just ask in your own words.",
  },
]

const fallbacksEn = [
  "I am still learning, so I may not have that answer. You could try a memory game, or ask how the week is going.",
  "I did not quite catch that. Would you like to see today's activities instead?",
  "Let's keep it simple. I can help with games, progress, or the daily routine.",
]
const fallbacksHi = [
  "मैं अभी भी सीख रहा हूं, इसलिए मेरे पास वह उत्तर नहीं हो सकता। आप एक मेमोरी गेम आज़मा सकते हैं, या पूछ सकते हैं कि सप्ताह कैसा चल रहा है।",
  "मैं समझ नहीं पाया। क्या आप इसके बजाय आज की गतिविधियां देखना चाहेंगे?",
  "इसे सरल रखते हैं। मैं गेम, प्रगति, या दिनचर्या में मदद कर सकता हूं।",
]

function replyTo(message, ctx) {
  if (!ctx) return "I don't see a linked patient on this account yet, so I can only help with general questions."
  const rule = rules.find((r) => r.match.test(message))
  if (rule) return rule.reply(ctx)
  const fallbacks = isHi(ctx) ? fallbacksHi : fallbacksEn
  return fallbacks[Math.floor(Math.random() * fallbacks.length)]
}

/** A trimmed, LLM-friendly snapshot of the context — avoids sending the full raw documents. */
function summarizeContextForLlm(ctx) {
  if (!ctx) return null
  return {
    talkingAboutThemself: ctx.isSelf,
    patientFirstName: ctx.subjectFirstName,
    cognitiveScore: ctx.profile.cognitiveScore,
    weeklyChangePercent: ctx.profile.weeklyChange,
    accuracyPercent: ctx.profile.accuracy,
    streakDays: ctx.profile.streak,
    activitiesDoneToday: ctx.profile.activitiesDone,
    activitiesTotalToday: ctx.profile.activitiesTotal,
    caregiverName: ctx.profile.caregiver,
    todaysReminders: ctx.reminders.map((r) => ({ title: r.title, time: r.timeLabel })),
    todaysWellness: ctx.wellness
      ? { mood: ctx.wellness.mood, sleepHours: ctx.wellness.sleepHours, waterGlasses: ctx.wellness.waterGlasses, waterGoal: ctx.wellness.waterGoal }
      : null,
    mostRecentGame: ctx.latest ? { name: gameNames[ctx.latest.game], score: ctx.latest.score, accuracy: ctx.latest.accuracy } : null,
  }
}

async function getAssistantReply(user, message) {
  const ctx = await buildContext(user)

  if (llmService.isEnabled()) {
    const llmReply = await llmService.generateReply(summarizeContextForLlm(ctx), message, ctx?.language)
    if (llmReply) return llmReply
    // fall through to the rule engine if the LLM call failed
  }

  return replyTo(message, ctx)
}

async function greetingFor(user) {
  const ctx = await buildContext(user)
  const subject = ctx ? null : await subjectPatientFor(user)
  const name = ctx ? ctx.subjectFirstName : subject?.name?.split(" ")[0] || "there"
  if (ctx && isHi(ctx)) {
    return `नमस्ते ${name}। मैं आपका MindCare सहायक हूं। आप टाइप कर सकते हैं, या माइक्रोफ़ोन दबाकर बोल सकते हैं। आज आप क्या करना चाहेंगे?`
  }
  return `Hello ${name}. I am your MindCare assistant. You can type, or press the microphone and speak to me. What would you like to do today?`
}

module.exports = { getAssistantReply, greetingFor }
