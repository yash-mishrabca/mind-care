const GameResult = require("../models/GameResult")
const ActivityCompletion = require("../models/ActivityCompletion")
const { GAME_IDS, gameNames } = require("../data/gamesCatalog")
const { dateKeyDaysAgo, dayStart, weekdayShort, weekdayLong } = require("../utils/dates")

/**
 * Fetches every game session + completed activity in the last `days` days in
 * exactly 2 queries and buckets them by day key. `weeklyScores` and
 * `streakCalendar` used to each run 2 queries PER DAY in a loop (up to ~180
 * queries for a 90-day range) — this replaces both with one batch fetch.
 */
async function fetchActivityWindow(userId, days) {
  const startKey = dateKeyDaysAgo(days - 1)
  const rangeStart = new Date(`${startKey}T00:00:00.000Z`)

  const [results, completions] = await Promise.all([
    GameResult.find({ userId, playedAt: { $gte: rangeStart } }).select("playedAt accuracy").lean(),
    ActivityCompletion.find({ userId, done: true, date: { $gte: startKey } }).select("date").lean(),
  ])

  const resultsByDay = new Map()
  for (const r of results) {
    const key = r.playedAt.toISOString().slice(0, 10)
    if (!resultsByDay.has(key)) resultsByDay.set(key, [])
    resultsByDay.get(key).push(r)
  }

  const activityCountByDay = new Map()
  for (const c of completions) {
    activityCountByDay.set(c.date, (activityCountByDay.get(c.date) || 0) + 1)
  }

  return { resultsByDay, activityCountByDay }
}

const VALID_RANGE_DAYS = [7, 30, 90]

/** One point per day for the last `days` days (oldest -> newest). Defaults to 7 to match the old behaviour. */
async function weeklyScores(userId, days = 7) {
  const span = VALID_RANGE_DAYS.includes(days) ? days : 7
  const { resultsByDay, activityCountByDay } = await fetchActivityWindow(userId, span)

  const out = []
  for (let i = span - 1; i >= 0; i--) {
    const key = dateKeyDaysAgo(i)
    const date = dayStart(i)
    const dayResults = resultsByDay.get(key) || []
    const avg = dayResults.length
      ? Math.round(dayResults.reduce((sum, r) => sum + r.accuracy, 0) / dayResults.length)
      : 0
    const activities = dayResults.length + (activityCountByDay.get(key) || 0)
    out.push({ date: key, day: weekdayShort(date), label: weekdayLong(date), score: avg, activities })
  }
  return out
}

/** Accuracy + session count per game, always includes every game in the catalog. */
async function gamePerformance(userId) {
  const results = []
  for (const gameId of GAME_IDS) {
    const rows = await GameResult.find({ userId, game: gameId }).select("accuracy").lean()
    const accuracy = rows.length ? Math.round(rows.reduce((sum, r) => sum + r.accuracy, 0) / rows.length) : 0
    results.push({ game: gameNames[gameId], gameId, accuracy, sessions: rows.length })
  }
  return results
}

/** Overall correct vs missed % across every session (lifetime, not range-scoped). */
async function accuracyBreakdown(userId) {
  const rows = await GameResult.find({ userId }).select("accuracy").lean()
  if (rows.length === 0) return [{ name: "Correct", value: 0 }, { name: "Missed", value: 0 }]
  const avg = Math.round(rows.reduce((sum, r) => sum + r.accuracy, 0) / rows.length)
  return [
    { name: "Correct", value: avg },
    { name: "Missed", value: 100 - avg },
  ]
}

/** GitHub-style 0-4 intensity per day for the last `weeks` weeks, oldest -> newest. */
async function streakCalendar(userId, weeks = 12) {
  const totalDays = weeks * 7
  const { resultsByDay, activityCountByDay } = await fetchActivityWindow(userId, totalDays)

  const values = []
  for (let i = totalDays - 1; i >= 0; i--) {
    const key = dateKeyDaysAgo(i)
    const sessions = (resultsByDay.get(key) || []).length
    const activityCount = activityCountByDay.get(key) || 0
    const total = sessions + activityCount
    let intensity = 0
    if (total >= 4) intensity = 4
    else if (total === 3) intensity = 3
    else if (total === 2) intensity = 2
    else if (total === 1) intensity = 1
    values.push(intensity)
  }
  return values
}

/** Top-line stats: total sessions, average accuracy, best score, total minutes played (lifetime). */
async function overallStats(userId) {
  const rows = await GameResult.find({ userId }).lean()
  if (rows.length === 0) return { sessions: 0, accuracy: 0, best: 0, minutes: 0 }
  return {
    sessions: rows.length,
    accuracy: Math.round(rows.reduce((sum, r) => sum + r.accuracy, 0) / rows.length),
    best: rows.reduce((max, r) => Math.max(max, r.score), 0),
    minutes: Math.round(rows.reduce((sum, r) => sum + r.durationSeconds, 0) / 60),
  }
}

/** `days` selects the range for the trend chart only (7/30/90); everything else stays lifetime. */
async function getAnalytics(userId, days = 7) {
  return {
    weeklyScores: await weeklyScores(userId, days),
    gamePerformance: await gamePerformance(userId),
    accuracyBreakdown: await accuracyBreakdown(userId),
    streakCalendar: await streakCalendar(userId),
    stats: await overallStats(userId),
  }
}

function csvEscape(value) {
  const str = String(value ?? "")
  if (/[",\n]/.test(str)) return `"${str.replace(/"/g, '""')}"`
  return str
}

/** CSV of every recorded game session (most recent first) — powers the caregiver's "Download report" button. */
async function gameResultsCsv(userId) {
  const rows = await GameResult.find({ userId }).sort({ playedAt: -1 }).lean()
  const header = ["Date", "Time (UTC)", "Game", "Score", "Accuracy (%)", "Duration (seconds)"]
  const lines = [header.join(",")]
  for (const r of rows) {
    const iso = r.playedAt.toISOString()
    lines.push(
      [iso.slice(0, 10), iso.slice(11, 19), gameNames[r.game] || r.game, r.score, r.accuracy, r.durationSeconds]
        .map(csvEscape)
        .join(","),
    )
  }
  return lines.join("\n")
}

module.exports = {
  weeklyScores,
  gamePerformance,
  accuracyBreakdown,
  streakCalendar,
  overallStats,
  getAnalytics,
  gameResultsCsv,
  VALID_RANGE_DAYS,
}
