/**
 * Optional LLM-backed assistant.
 *
 * The rule-based assistant in assistantService.js works out of the box with
 * no configuration. If the person running this app sets ANTHROPIC_API_KEY,
 * we instead ground a real Claude call in the same patient context (profile,
 * today's activities/wellness, recent reminders) that the rule engine uses,
 * so the two modes give consistent, personalized behavior.
 *
 * Nothing else in the app depends on this file being configured — every
 * caller must handle isEnabled() === false and fall back gracefully.
 */

const MODEL = process.env.ANTHROPIC_MODEL || null
const API_KEY = process.env.ANTHROPIC_API_KEY || null

function isEnabled() {
  return Boolean(API_KEY && MODEL)
}

function systemPromptFor(context, language) {
  const lines = [
    "You are the in-app companion assistant inside MindCare, a memory-care app for a patient and their caregiver.",
    "You are warm, brief, and never clinical. You are not a doctor and must not diagnose, prescribe, or give medical advice — encourage the person to talk to their real doctor or caregiver for anything medical.",
    "Keep replies short (2-4 sentences) and easy to read for someone who may have memory difficulties. Avoid jargon.",
    `Reply in this language: ${language || "en"} (fall back to English only if you cannot write the requested language).`,
    "",
    "Here is what you know about the person you're talking to right now:",
    JSON.stringify(context, null, 2),
    "",
    "If the message suggests the person may be in danger, distressed, or asking for emergency help, gently tell them to use the SOS button in the app or contact their caregiver/emergency services directly, in addition to responding with care.",
  ]
  return lines.join("\n")
}

/**
 * Returns a plain-text reply, or null if the LLM is not configured / the
 * call fails — callers should treat null as "use the rule-based fallback".
 */
async function generateReply(context, message, language) {
  if (!isEnabled()) return null

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 300,
        system: systemPromptFor(context, language),
        messages: [{ role: "user", content: message }],
      }),
    })

    if (!response.ok) {
      console.error("[llmService] Anthropic API error:", response.status, await response.text())
      return null
    }

    const data = await response.json()
    const text = (data.content || [])
      .filter((block) => block.type === "text")
      .map((block) => block.text)
      .join("\n")
      .trim()

    return text || null
  } catch (err) {
    console.error("[llmService] request failed:", err.message)
    return null
  }
}

module.exports = { isEnabled, generateReply }
