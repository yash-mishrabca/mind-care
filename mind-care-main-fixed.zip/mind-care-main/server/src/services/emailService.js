/**
 * No SMTP/email-API provider is configured for this project. This stub is
 * the extension point: swap the body of sendPasswordResetEmail for a real
 * provider (Nodemailer, Resend, Postmark, SES, ...) to actually deliver
 * email. Until that's wired up, callers must NOT rely on the reset token
 * reaching the user any other way (e.g. by returning it in an API response)
 * — see config.exposeDevResetToken / auth.routes.js.
 */
async function sendPasswordResetEmail(toEmail, resetToken) {
  console.log(`[emailService] (stub) Password reset requested for ${toEmail}.`)
  if (process.env.NODE_ENV !== "production") {
    console.log(`[emailService] (stub) Reset token (dev-only log, never sent to the browser): ${resetToken}`)
  } else {
    console.log(
      "[emailService] (stub) No email provider is configured — the reset token was generated but not delivered. " +
        "Wire up a real provider in server/src/services/emailService.js before relying on this in production.",
    )
  }
}

module.exports = { sendPasswordResetEmail }
