const express = require("express")
const asyncHandler = require("../utils/asyncHandler")
const { assert } = require("../utils/ApiError")
const { requireAuth, requireRole } = require("../middleware/auth")
const PatientProfile = require("../models/PatientProfile")
const { getPatientProfile, getRecentActivity, findCaregiversForPatient } = require("../services/profileService")
const { getInviteCode } = require("../services/userService")
const { createSosAlert } = require("../services/alertService")

const router = express.Router()

// GET /api/patients/me
// Mirrors `getPatientData()` in lib/api.ts: { profile, activity }
router.get(
  "/me",
  requireAuth,
  requireRole("patient"),
  asyncHandler(async (req, res) => {
    res.json({
      profile: await getPatientProfile(req.user.id),
      activity: await getRecentActivity(req.user.id, 3),
    })
  }),
)

// GET /api/patients/me/invite-code
// The code a patient shares with their caregiver so the caregiver's account
// can be linked to see this patient's data.
router.get(
  "/me/invite-code",
  requireAuth,
  requireRole("patient"),
  asyncHandler(async (req, res) => {
    res.json({ inviteCode: await getInviteCode(req.user.id) })
  }),
)

// PATCH /api/patients/me/phone   { phone: string | null }
// A real contact number so a caregiver's "Call" button dials someone real
// instead of a hardcoded placeholder.
router.patch(
  "/me/phone",
  requireAuth,
  requireRole("patient"),
  asyncHandler(async (req, res) => {
    const { phone } = req.body || {}
    assert(phone === null || typeof phone === "string", 400, "phone must be a string or null.")
    const trimmed = typeof phone === "string" ? phone.trim() : ""
    if (trimmed) {
      assert(/^[0-9+()\-.\s]{6,20}$/.test(trimmed), 400, "Please provide a valid phone number.")
    }
    await PatientProfile.updateOne({ _id: req.user.id }, { $set: { phone: trimmed || null } })
    res.json({ profile: await getPatientProfile(req.user.id) })
  }),
)

// PATCH /api/patients/me/timezone   { offsetMinutes }
// The frontend calls this automatically (from the browser's own timezone)
// so alertService can evaluate "missed activity" / "it's afternoon" style
// checks in the patient's real local time instead of a fixed default.
router.patch(
  "/me/timezone",
  requireAuth,
  requireRole("patient"),
  asyncHandler(async (req, res) => {
    const { offsetMinutes } = req.body || {}
    assert(
      Number.isFinite(offsetMinutes) && offsetMinutes >= -720 && offsetMinutes <= 840,
      400,
      "offsetMinutes must be a valid UTC offset in minutes.",
    )
    await PatientProfile.updateOne({ _id: req.user.id }, { $set: { timezoneOffsetMinutes: Math.round(offsetMinutes) } })
    res.json({ ok: true })
  }),
)

// POST /api/patients/me/sos   { message? }
// Immediately raises a high-priority alert for every linked caregiver. This
// is never deduped/suppressed the way routine alerts are — a person pressing
// SOS should always get through.
router.post(
  "/me/sos",
  requireAuth,
  requireRole("patient"),
  asyncHandler(async (req, res) => {
    const caregivers = await findCaregiversForPatient(req.user.id)
    // CaregiverAlert is keyed by patientId, not caregiverId — every linked
    // caregiver already sees the same alert when they view this patient, so
    // only one needs to be created regardless of how many caregivers there are.
    await createSosAlert(req.user.id, req.body?.message)
    res.json({ ok: true, notifiedCaregivers: caregivers.length })
  }),
)

module.exports = router
