const express = require("express")
const asyncHandler = require("../utils/asyncHandler")
const { ApiError, assert } = require("../utils/ApiError")
const { requireAuth } = require("../middleware/auth")
const {
  createUser,
  findByEmail,
  verifyPassword,
  createPasswordResetToken,
  consumePasswordResetToken,
  updatePassword,
} = require("../services/userService")
const { sendPasswordResetEmail } = require("../services/emailService")
const { signToken } = require("../utils/jwt")
const { getPatientProfile, getCaregiverProfile } = require("../services/profileService")
const config = require("../config")

const router = express.Router()

const EMAIL_RE = /^\S+@\S+\.\S+$/

async function shapedProfile(user) {
  return user.role === "patient" ? getPatientProfile(user.id) : getCaregiverProfile(user.id)
}

// POST /api/auth/signup
router.post(
  "/signup",
  asyncHandler(async (req, res) => {
    const { name, email, password, role } = req.body || {}

    assert(typeof name === "string" && name.trim().length > 0, 400, "Please provide a name.")
    assert(typeof email === "string" && EMAIL_RE.test(email), 400, "Please provide a valid email address.")
    assert(typeof password === "string" && password.length >= 6, 400, "Password must be at least 6 characters.")
    assert(role === "patient" || role === "caregiver", 400, "Role must be 'patient' or 'caregiver'.")

    const { user, error } = await createUser({ name, email, password, role })
    if (error === "email-taken") throw new ApiError(409, "An account with that email already exists.")

    const token = signToken(user)
    res.status(201).json({ token, role: user.role, user: await shapedProfile(user) })
  }),
)

// POST /api/auth/login  { email, password }
router.post(
  "/login",
  asyncHandler(async (req, res) => {
    const { email, password } = req.body || {}
    assert(typeof email === "string" && typeof password === "string", 400, "Email and password are required.")

    const user = await findByEmail(email)
    assert(user && verifyPassword(user, password), 401, "Incorrect email or password.")

    const token = signToken(user)
    res.json({ token, role: user.role, user: await shapedProfile(user) })
  }),
)

// POST /api/auth/forgot-password  { email }
// SECURITY: no real email provider is configured for this project (see
// services/emailService.js), so historically the reset token was returned
// directly in this response for demo convenience. That let anyone who knew
// (or guessed) a user's email take over the account with no access to their
// inbox. The token is now only ever handed to the client when
// config.exposeDevResetToken is true (default: non-production only) — swap
// emailService for a real provider and this becomes safe to run as-is in
// production with that flag left off.
router.post(
  "/forgot-password",
  asyncHandler(async (req, res) => {
    const { email } = req.body || {}
    assert(typeof email === "string" && EMAIL_RE.test(email), 400, "Please provide a valid email address.")

    const user = await findByEmail(email)
    if (!user) {
      return res.json({ message: "If that email has an account, a reset link has been created." })
    }

    const token = await createPasswordResetToken(user.id)
    await sendPasswordResetEmail(user.email, token)

    const payload = { message: "If that email has an account, a reset link has been created." }
    if (config.exposeDevResetToken) {
      payload.devResetToken = token
      payload.devNote = "No email service is configured — this token is returned directly for development/demo purposes only."
    }
    res.json(payload)
  }),
)

// POST /api/auth/reset-password  { token, newPassword }
router.post(
  "/reset-password",
  asyncHandler(async (req, res) => {
    const { token, newPassword } = req.body || {}
    assert(typeof token === "string" && token.length > 0, 400, "Reset token is required.")
    assert(typeof newPassword === "string" && newPassword.length >= 6, 400, "Password must be at least 6 characters.")

    const userId = await consumePasswordResetToken(token)
    assert(userId, 400, "This reset link is invalid or has expired. Please request a new one.")

    await updatePassword(userId, newPassword)
    res.json({ message: "Password updated. You can now log in with your new password." })
  }),
)

// GET /api/auth/me
router.get(
  "/me",
  requireAuth,
  asyncHandler(async (req, res) => {
    res.json({ role: req.user.role, user: await shapedProfile(req.user) })
  }),
)

module.exports = router
