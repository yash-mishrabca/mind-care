const express = require("express")
const asyncHandler = require("../utils/asyncHandler")
const { requireAuth } = require("../middleware/auth")
const { resolveTargetPatientId, getPatientProfile } = require("../services/profileService")
const { getAnalytics, gameResultsCsv, VALID_RANGE_DAYS } = require("../services/analyticsService")

const router = express.Router()

function parseRangeDays(raw) {
  const parsed = parseInt(raw, 10)
  return VALID_RANGE_DAYS.includes(parsed) ? parsed : 7
}

// GET /api/analytics?patientId=&days=7|30|90
// Mirrors `getAnalytics()` in lib/api.ts, computed from real stored results.
// `days` controls the trend-chart range only (lifetime stats are unaffected)
// — this used to be accepted by nothing, so the frontend's 7/30/90 selector
// only ever changed a label, never the data.
router.get(
  "/",
  requireAuth,
  asyncHandler(async (req, res) => {
    const targetId = await resolveTargetPatientId(req.user, req.query.patientId)
    const days = parseRangeDays(req.query.days)
    res.json(await getAnalytics(targetId, days))
  }),
)

// GET /api/analytics/export.csv?patientId=
// A downloadable CSV of every recorded game session, for a caregiver who
// wants something to bring to a doctor's visit.
router.get(
  "/export.csv",
  requireAuth,
  asyncHandler(async (req, res) => {
    const targetId = await resolveTargetPatientId(req.user, req.query.patientId)
    const [csv, profile] = await Promise.all([gameResultsCsv(targetId), getPatientProfile(targetId)])
    const filename = `${(profile?.name || "mindcare-patient").replace(/[^a-z0-9]+/gi, "-").toLowerCase()}-report.csv`

    res.setHeader("Content-Type", "text/csv; charset=utf-8")
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`)
    res.send(csv)
  }),
)

module.exports = router
