"use client"

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react"
import { STORAGE_KEYS, readValue, removeValue, storageAvailable, writeValue, clearAccountScopedLocalData } from "@/lib/storage"
import { clearToken, getPreferences, isAuthenticated, updatePreferencesRemote } from "@/lib/api"
import { useTranslation } from "@/lib/i18n"
import type { Role } from "@/lib/mock-data"

export type Preferences = {
  theme: "light" | "dark"
  elderMode: boolean
  fontScale: "normal" | "large" | "xlarge"
  reduceMotion: boolean
  notifications: boolean
  sound: boolean
  language: "en" | "hi" | "as" | "brx" | "kha" | "lus" | "mni"
  shareWithCaregiver: boolean
}

const defaultPreferences: Preferences = {
  theme: "light",
  elderMode: false,
  fontScale: "normal",
  reduceMotion: false,
  notifications: true,
  sound: true,
  language: "en",
  shareWithCaregiver: true,
}

const fontSizes: Record<Preferences["fontScale"], string> = {
  normal: "16px",
  large: "18px",
  xlarge: "21px",
}

type AppContextValue = {
  role: Role | null
  displayName: string | null
  ready: boolean
  storageOk: boolean
  preferences: Preferences
  login: (role: Role, name?: string) => void
  logout: () => void
  setDisplayName: (name: string) => void
  setPreference: <K extends keyof Preferences>(key: K, value: Preferences[K]) => void
}

const AppContext = createContext<AppContextValue | null>(null)

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [role, setRole] = useState<Role | null>(null)
  const [displayName, setDisplayNameState] = useState<string | null>(null)
  const [preferences, setPreferences] = useState<Preferences>(defaultPreferences)
  const [ready, setReady] = useState(false)
  const [storageOk, setStorageOk] = useState(true)
  // AppProvider always renders inside I18nProvider (see app/layout.tsx), so
  // this is safe to call here.
  const { language: i18nLanguage, setLanguage: setI18nLanguage } = useTranslation()
  const i18nLanguageRef = useRef(i18nLanguage)
  useEffect(() => {
    i18nLanguageRef.current = i18nLanguage
  }, [i18nLanguage])

  useEffect(() => {
    setStorageOk(storageAvailable())
    setRole(readValue<Role | null>(STORAGE_KEYS.userRole, null))
    setDisplayNameState(readValue<string | null>(STORAGE_KEYS.userName, null))
    setPreferences({ ...defaultPreferences, ...readValue<Partial<Preferences>>(STORAGE_KEYS.preferences, {}) })
    setReady(true)
  }, [])

  // Once logged in, pull the server copy of preferences so they follow the
  // account across devices. Falls back silently to the local copy if the
  // backend is unreachable.
  useEffect(() => {
    if (!ready || !role || !isAuthenticated()) return
    let cancelled = false
    getPreferences()
      .then((remote) => {
        if (cancelled) return
        setPreferences((prev) => {
          const merged = { ...prev, ...remote }
          writeValue(STORAGE_KEYS.preferences, merged)
          // Bug fix: this used to only update AppProvider's own state.
          // I18nProvider (which actually drives every t() call) has its own
          // separate language state, so a language chosen on another device
          // never actually changed the UI's text here until the person
          // manually reopened Settings. Push it through explicitly.
          if (merged.language !== i18nLanguageRef.current) setI18nLanguage(merged.language)
          return merged
        })
      })
      .catch(() => {
        /* keep local preferences */
      })
    return () => {
      cancelled = true
    }
  }, [ready, role, setI18nLanguage])

  // Apply preferences to the document root.
  useEffect(() => {
    if (!ready) return
    const root = document.documentElement
    root.classList.toggle("dark", preferences.theme === "dark")
    root.classList.toggle("elder-mode", preferences.elderMode)
    root.classList.toggle("reduce-motion", preferences.reduceMotion)
    const scale = preferences.elderMode && preferences.fontScale === "normal" ? "large" : preferences.fontScale
    root.style.setProperty("--app-font-size", fontSizes[scale])
  }, [preferences, ready])

  const setPreference = useCallback(
    <K extends keyof Preferences>(key: K, value: Preferences[K]) => {
      setPreferences((prev) => {
        const next = { ...prev, [key]: value }
        writeValue(STORAGE_KEYS.preferences, next)
        if (isAuthenticated()) {
          void updatePreferencesRemote({ [key]: value }).catch(() => {
            /* best-effort sync — local value already applied */
          })
        }
        return next
      })
      // Bug fix: previously only the Settings page remembered to call both
      // setPreference("language", ...) and i18n's setLanguage separately.
      // Centralizing it here means every caller stays in sync automatically.
      if (key === "language") setI18nLanguage(value as Preferences["language"])
    },
    [setI18nLanguage],
  )

  const login = useCallback((next: Role, name?: string) => {
    writeValue(STORAGE_KEYS.userRole, next)
    setRole(next)
    if (name && name.trim()) {
      writeValue(STORAGE_KEYS.userName, name.trim())
      setDisplayNameState(name.trim())
    }
  }, [])

  const setDisplayName = useCallback((name: string) => {
    writeValue(STORAGE_KEYS.userName, name)
    setDisplayNameState(name)
  }, [])

  const logout = useCallback(() => {
    removeValue(STORAGE_KEYS.userRole)
    clearToken()
    clearAccountScopedLocalData()
    setRole(null)
    setDisplayNameState(null)
    setPreferences(defaultPreferences)
  }, [])

  const value = useMemo<AppContextValue>(
    () => ({ role, displayName, ready, storageOk, preferences, login, logout, setDisplayName, setPreference }),
    [role, displayName, ready, storageOk, preferences, login, logout, setDisplayName, setPreference],
  )

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error("useApp must be used inside AppProvider")
  return ctx
}
