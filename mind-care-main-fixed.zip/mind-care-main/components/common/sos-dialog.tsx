"use client"

import { useState } from "react"
import { AlertTriangle, CheckCircle2 } from "lucide-react"
import { Card } from "@/components/common/card"
import { triggerSos } from "@/lib/api"

export function SosDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [sending, setSending] = useState(false)
  const [sent, setSent] = useState(false)
  const [error, setError] = useState<string | null>(null)

  if (!open) return null

  const send = async () => {
    setSending(true)
    setError(null)
    try {
      await triggerSos()
      setSent(true)
    } catch {
      setError("Could not reach the server. Please call your caregiver directly, or try again.")
    } finally {
      setSending(false)
    }
  }

  const close = () => {
    onClose()
    // Reset for next time, after the closing transition would have finished.
    setTimeout(() => {
      setSent(false)
      setError(null)
    }, 200)
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/40 px-4" role="dialog" aria-modal="true" aria-label="Send SOS alert">
      <Card className="w-full max-w-sm text-center">
        {sent ? (
          <>
            <span className="mx-auto flex size-16 items-center justify-center rounded-2xl bg-success/12 text-success" aria-hidden="true">
              <CheckCircle2 className="size-8" />
            </span>
            <h2 className="mt-4 font-display text-xl font-semibold">Your caregiver has been alerted</h2>
            <p className="mt-2 text-muted-foreground text-pretty">
              They will see this the next time they check the app. If this is a medical emergency, please also call
              your local emergency number.
            </p>
            <button
              type="button"
              onClick={close}
              className="tap-target mt-6 flex h-14 w-full items-center justify-center rounded-xl bg-primary font-semibold text-primary-foreground"
            >
              Close
            </button>
          </>
        ) : (
          <>
            <span className="mx-auto flex size-16 items-center justify-center rounded-2xl bg-destructive/12 text-destructive" aria-hidden="true">
              <AlertTriangle className="size-8" />
            </span>
            <h2 className="mt-4 font-display text-xl font-semibold">Send an SOS to your caregiver?</h2>
            <p className="mt-2 text-muted-foreground text-pretty">
              This will immediately alert everyone linked to your account. If you are in immediate danger, please
              call your local emergency number first.
            </p>
            {error ? <p className="mt-3 rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive">{error}</p> : null}
            <div className="mt-6 flex flex-col gap-3 sm:flex-row">
              <button
                type="button"
                onClick={close}
                className="tap-target flex h-14 flex-1 items-center justify-center rounded-xl border border-border font-semibold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => void send()}
                disabled={sending}
                className="tap-target flex h-14 flex-1 items-center justify-center rounded-xl bg-destructive font-semibold text-destructive-foreground disabled:opacity-60"
              >
                {sending ? "Sending…" : "Yes, send SOS"}
              </button>
            </div>
          </>
        )}
      </Card>
    </div>
  )
}
