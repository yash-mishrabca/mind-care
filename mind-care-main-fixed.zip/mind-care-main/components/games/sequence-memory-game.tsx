"use client"

import { useCallback, useEffect, useRef, useState } from "react"
import { ListOrdered, Play } from "lucide-react"
import { GameFrame, GameResult } from "@/components/games/game-frame"
import { Card } from "@/components/common/card"
import { saveGameResult, getPersonalBest } from "@/lib/api"
import { cn } from "@/lib/utils"

const GRID = 4 // 2x2 board
const TOTAL_ROUNDS = 5
type Phase = "idle" | "showing" | "input" | "feedback" | "done"

// Theme tokens (not raw hex) so the four tiles stay readable in both light
// and dark mode, matching how the other games color their tiles.
const TILE_TONE = [
  "border-primary bg-primary text-primary-foreground",
  "border-secondary bg-secondary text-secondary-foreground",
  "border-accent bg-accent text-accent-foreground",
  "border-warning bg-warning text-warning-foreground",
]

function pickSequence(length: number): number[] {
  const seq: number[] = []
  for (let i = 0; i < length; i++) {
    let next = Math.floor(Math.random() * GRID)
    while (seq.length > 0 && next === seq[seq.length - 1]) {
      next = Math.floor(Math.random() * GRID)
    }
    seq.push(next)
  }
  return seq
}

export function SequenceMemoryGame() {
  const [round, setRound] = useState(1)
  const [phase, setPhase] = useState<Phase>("idle")
  const [sequence, setSequence] = useState<number[]>([])
  const [showIndex, setShowIndex] = useState(-1)
  const [inputIndex, setInputIndex] = useState(0)
  const [activeTap, setActiveTap] = useState<number | null>(null)
  const [correctRounds, setCorrectRounds] = useState(0)
  const [tapsCorrect, setTapsCorrect] = useState(0)
  const [tapsTotal, setTapsTotal] = useState(0)
  const [score, setScore] = useState(0)
  const [seconds, setSeconds] = useState(0)
  const [best, setBest] = useState(0)
  const [isNewBest, setIsNewBest] = useState(false)
  const [saved, setSaved] = useState(false)
  const [lastRoundOk, setLastRoundOk] = useState<boolean | null>(null)
  const timers = useRef<ReturnType<typeof setTimeout>[]>([])

  const clearTimers = () => {
    timers.current.forEach(clearTimeout)
    timers.current = []
  }

  const reset = useCallback(() => {
    clearTimers()
    setRound(1)
    setPhase("idle")
    setSequence([])
    setShowIndex(-1)
    setInputIndex(0)
    setActiveTap(null)
    setCorrectRounds(0)
    setTapsCorrect(0)
    setTapsTotal(0)
    setScore(0)
    setSeconds(0)
    setSaved(false)
    setIsNewBest(false)
    setLastRoundOk(null)
    // `best` is intentionally left alone here — it comes from the backend
    // (see effect below) and is kept current locally after each save.
  }, [])

  useEffect(() => {
    reset()
    return clearTimers
  }, [reset])

  useEffect(() => {
    let cancelled = false
    getPersonalBest("sequence-memory").then((value) => {
      if (!cancelled) setBest(value)
    })
    return () => {
      cancelled = true
    }
  }, [])

  useEffect(() => {
    if (phase === "done" || phase === "idle") return
    const id = setInterval(() => setSeconds((s) => s + 1), 1000)
    return () => clearInterval(id)
  }, [phase])

  const startRound = (roundNumber: number) => {
    const length = Math.min(3 + Math.floor((roundNumber - 1) / 2), 6)
    const seq = pickSequence(length)
    setSequence(seq)
    setInputIndex(0)
    setShowIndex(-1)
    setLastRoundOk(null)
    setPhase("showing")

    seq.forEach((_, i) => {
      const onTimer = setTimeout(() => setShowIndex(i), i * 700)
      const offTimer = setTimeout(() => setShowIndex(-1), i * 700 + 450)
      timers.current.push(onTimer, offTimer)
    })
    const doneTimer = setTimeout(() => setPhase("input"), seq.length * 700 + 200)
    timers.current.push(doneTimer)
  }

  const accuracy = tapsTotal === 0 ? 100 : Math.round((tapsCorrect / tapsTotal) * 100)

  const finishRound = (correctCount: number, perfect: boolean) => {
    setTapsCorrect((c) => c + correctCount)
    setTapsTotal((t) => t + sequence.length)
    setScore((s) => s + correctCount * 60 + (perfect ? 120 : 0))
    if (perfect) setCorrectRounds((c) => c + 1)
    setLastRoundOk(perfect)
    setPhase("feedback")

    const t = setTimeout(() => {
      if (round >= TOTAL_ROUNDS) {
        setPhase("done")
      } else {
        setRound((r) => r + 1)
        startRound(round + 1)
      }
    }, 1500)
    timers.current.push(t)
  }

  const handleTap = (tileIndex: number) => {
    if (phase !== "input") return
    setActiveTap(tileIndex)
    timers.current.push(setTimeout(() => setActiveTap(null), 220))

    if (tileIndex === sequence[inputIndex]) {
      const nextInputIndex = inputIndex + 1
      if (nextInputIndex === sequence.length) {
        finishRound(nextInputIndex, true)
      } else {
        setInputIndex(nextInputIndex)
      }
    } else {
      // A slip ends the round here — whatever was tapped correctly so far still counts.
      finishRound(inputIndex, false)
    }
  }

  useEffect(() => {
    if (phase !== "done" || saved) return
    setSaved(true)
    setIsNewBest(score > best)
    setBest((prev) => Math.max(prev, score))
    void saveGameResult({ game: "sequence-memory", score, accuracy, durationSeconds: seconds })
  }, [phase, saved, score, accuracy, seconds, best])

  const instruction =
    phase === "idle"
      ? "Watch the tiles light up one at a time in order, then tap them back in that exact order. Five gentle rounds."
      : phase === "showing"
        ? "Watch carefully — remember the order."
        : phase === "input"
          ? `Now tap the ${sequence.length} tiles back in the same order.`
          : phase === "feedback"
            ? lastRoundOk
              ? "Correct! Well remembered."
              : "Close — the full sequence is shown below."
            : "Round complete."

  return (
    <GameFrame
      title="Sequence Memory"
      instruction={instruction}
      score={score}
      accuracy={accuracy}
      seconds={seconds}
      round={phase === "done" ? TOTAL_ROUNDS : round}
      totalRounds={TOTAL_ROUNDS}
      onRestart={reset}
    >
      {phase === "done" ? (
        <GameResult score={score} accuracy={accuracy} seconds={seconds} best={best} isNewBest={isNewBest} onRestart={reset} />
      ) : (
        <Card className="flex flex-col items-center gap-6">
          {phase === "idle" ? (
            <div className="flex flex-col items-center gap-5 py-8 text-center">
              <span className="flex size-20 items-center justify-center rounded-2xl bg-warning/12 text-warning" aria-hidden="true">
                <ListOrdered className="size-10" />
              </span>
              <div>
                <h2 className="font-display text-xl font-semibold tracking-tight sm:text-2xl">Ready when you are</h2>
                <p className="mt-2 max-w-sm text-muted-foreground text-pretty">
                  Four tiles will light up one by one. Tap them back in the same order. There is no penalty for
                  mistakes.
                </p>
              </div>
              <button
                type="button"
                onClick={() => startRound(1)}
                className="tap-target flex h-14 items-center gap-2 rounded-xl bg-warning px-8 font-semibold text-warning-foreground transition-transform hover:-translate-y-0.5"
              >
                <Play className="size-5" aria-hidden="true" />
                Start round 1
              </button>
            </div>
          ) : (
            <>
              <ul className="grid w-full max-w-xs grid-cols-2 gap-4">
                {Array.from({ length: GRID }, (_, index) => {
                  const lit = phase === "showing" && showIndex === index
                  const tapped = phase === "input" && activeTap === index
                  const revealTile = phase === "feedback" && sequence.includes(index)
                  const isActive = lit || tapped || revealTile
                  return (
                    <li key={index} className="aspect-square">
                      <button
                        type="button"
                        onClick={() => handleTap(index)}
                        disabled={phase !== "input"}
                        aria-label={`Tile ${index + 1}`}
                        className={cn(
                          "flex size-full items-center justify-center rounded-2xl border-2 text-2xl font-display font-semibold transition-all duration-150",
                          isActive ? TILE_TONE[index] : "border-border bg-muted/50",
                          phase === "input" && "hover:border-primary/60",
                        )}
                      >
                        {phase === "feedback" && sequence.includes(index)
                          ? sequence.reduce((acc, v, i) => (v === index ? [...acc, i + 1] : acc), [] as number[]).join(", ")
                          : null}
                      </button>
                    </li>
                  )
                })}
              </ul>

              <p className="text-sm text-muted-foreground" aria-live="polite">
                {phase === "input"
                  ? `${inputIndex} of ${sequence.length} tapped correctly`
                  : phase === "showing"
                    ? "Memorise the order…"
                    : `Round ${round} of ${TOTAL_ROUNDS} · ${correctRounds} perfect so far`}
              </p>
            </>
          )}
        </Card>
      )}
    </GameFrame>
  )
}
