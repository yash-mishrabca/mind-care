# Changelog

This pass fixed every bug identified in a full code review, then built out
real (not stubbed) versions of six feature areas on top of the fixes. Every
backend file was syntax-checked (`node --check`) and the full module graph
was loaded to catch import/circular-dependency errors. The entire frontend
passes `tsc --noEmit` (including `--noUnusedLocals --noUnusedParameters`)
with zero errors, and a production `next build` succeeds up to the point
where the sandbox this was built in blocks outbound access to Google Fonts —
unrelated to any app code.

## Bug fixes

### Security
- **Password reset no longer leaks the reset token to the client by
  default.** `POST /auth/forgot-password` used to always return the raw
  token in the response so the demo UI could link straight to the reset
  page — since there's no email step, anyone who knew a user's email could
  take over their account. The token is now only returned when
  `config.exposeDevResetToken` is true (default: non-production only), and
  is routed through a new pluggable `services/emailService.js` stub either
  way. See `.env.example`'s `EXPOSE_DEV_RESET_TOKEN`.

### Cross-account / data-integrity
- **Logging out now fully clears local state.** `logout()` previously only
  cleared the role and JWT — `displayName`, cached preferences, and the
  offline-fallback game-result/chat-history caches survived. On a shared
  device, a second person signing in could inherit the previous account's
  cached data. `lib/storage.ts` now exposes `clearAccountScopedLocalData()`,
  called on every logout.
- **Fixed the offline-fallback ID collision bug that was only fixed
  server-side.** `saveGameResultLocal()` used ``${game}-${Date.now()}`` —
  exactly the pattern the backend was rewritten to avoid. Now uses
  `crypto.randomUUID()` (with a fallback for very old browsers).

### "Personal Best" wasn't the real personal best
- All three original game screens and the games hub imported the
  **local-only** `personalBest()` instead of the backend-aware
  `getPersonalBest()` that already existed in `lib/api.ts` but was never
  called. Fixed in `card-match-game.tsx`, `pattern-recall-game.tsx`,
  `word-recall-game.tsx`, and `games-hub.tsx` — every game now fetches the
  real account-wide best and correctly computes "New personal best!" against
  the pre-round value.

### Real data was mixed with mock data
- **Analytics page**: "Cognitive score" and "Current streak" were hardcoded
  to the demo profile forever. Now fetched from the real linked patient's
  profile (`getPatientData`/`getCaregiverData`).
- **Caregiver dashboard adherence list**: always rendered the static mock
  activity list, even though the header counts above it used real data. Now
  fetches `getWellnessToday(patientId)` and renders the real list.
- **"Call" button**: was hardcoded to a fake number. Patients can now add a
  real phone number in Settings; the caregiver dashboard uses it (or shows
  a clear "No phone on file" state).
- **Analytics range selector** (7/30/90 days): only ever changed a label —
  the backend always returned a fixed 7-day window. `weeklyScores` /
  `getAnalytics` / the `/analytics` route now accept and use a real `days`
  parameter.

### Wellness tracking was mostly non-functional
- Mood and sleep had **no editing UI anywhere** — only their defaults could
  ever display. Steps had no logging UI either, and the backend never
  capped the value. All three now have real UI on the patient dashboard
  (mood picker, sleep +/‑ 0.5h stepper, steps +500 button), and the backend
  validates mood against a known list, clamps sleep to 0–24h, and caps steps
  at 60,000/day.

### Timezone bug
- `alertService.js` compared `new Date().getUTCHours()` against times
  patients typed in their own local time, shifting every "missed activity" /
  "no water logged this afternoon" alert by up to ~5.5 hours for IST users
  (this app's primary audience). `PatientProfile.timezoneOffsetMinutes` is
  now synced automatically from the browser and used for every time-of-day
  check.

### Backend robustness
- A malformed `:id`/`:activityId` path param (e.g. not a real ObjectId) used
  to throw an unhandled Mongoose `CastError`, surfaced as an opaque 500.
  `errorHandler.js` now turns `CastError`/`ValidationError`/duplicate-key
  errors into proper 4xx responses.
- `PATCH /wellness/today`'s check-then-`create()` was a real (if narrow)
  race condition on the unique `{userId, date}` index. Rewritten as an
  atomic `findOneAndUpdate` upsert.
- `computeStreak()` ran up to 400 loop iterations × 2 awaited queries (up to
  800 sequential DB round trips) on *every* profile/dashboard load.
  `weeklyScores`/`streakCalendar` in `analyticsService.js` had the same
  per-day-in-a-loop pattern. All three now fetch their full date range in a
  fixed 2 queries and compute in memory.

### Minor
- The weekly trend chart's Y-axis was hardcoded to `[60, 100]`, clipping any
  real score below 60 off the bottom of the chart. Now adapts its floor to
  the actual data (still capped at 60 so typical high scores stay "zoomed
  in").
- `ProgressBar` didn't clamp its `value` prop — an over-goal metric (e.g.
  steps past the daily goal) produced an invalid `aria-valuenow` above
  `aria-valuemax` and a bar wider than its own track. Now clamped to
  `[0, 100]`.
- Fixed a pre-existing TypeScript error in the polymorphic `Card`
  component (`as="li"` etc. didn't structurally match
  `HTMLAttributes<HTMLDivElement>`'s event handler types).
- The client-side fallback assistant and the "Notifications"/"Sound"
  settings copy referenced only 3 games / did nothing, respectively — now
  mention all 4 games and actually request permission / play a chime.

## Features added

1. **Wellness tracking, closed** — mood picker, sleep stepper, and a steps
   button are wired to the backend on the patient dashboard (see bug fixes
   above for the validation side of this).

2. **Real notifications & reminders**
   - `lib/notifications.ts`: schedules a browser `Notification` (+ optional
     synthesized chime, no audio asset needed) for each reminder with a
     fixed clock time, while the app tab is open. Permission is requested
     from a direct user gesture (the Settings toggle), not silently on load.
   - **Limitation, by design**: there's no push infrastructure (a service
     worker + VAPID keys + a push server) wired up, so this can't wake a
     closed browser or a locked phone. Treat it as "a gentle nudge while
     the app is open." Wiring up real web push, or SMS via a provider like
     Twilio, is a clean next step — the reminder data model doesn't need to
     change for either.
   - Caregivers can now create/delete reminders for a linked patient, not
     just view them (`reminders.routes.js` + `lib/api.ts`).

3. **Trustworthy caregiver monitoring**
   - Real adherence data and a real phone number (see bug fixes).
   - **Live alerts**: `GET /caregivers/me/alerts/stream` is a Server-Sent
     Events endpoint that re-evaluates and pushes a patient's alert list
     every ~20s. The caregiver dashboard subscribes via
     `openAlertsStream()` in `lib/api.ts`. (EventSource can't set an
     Authorization header, so this one read-only endpoint also accepts the
     token as `?token=` via `requireAuthFromHeaderOrQuery`.)
   - **Downloadable report**: `GET /analytics/export.csv` + a "Download
     report" button on both the caregiver dashboard and the analytics page,
     for bringing something concrete to a doctor's visit.

4. **Deeper cognitive game experience**
   - **A 4th game, Sequence Memory** (`components/games/sequence-memory-game.tsx`):
     a Simon-says-style ordered-recall game, distinct from the existing
     spatial-pattern game. Fully wired through the games catalog, the
     `GameResult` schema, the dynamic route, and two new achievements
     ("Sequence Master", "All-Rounder").
   - Real cross-device personal bests (see bug fixes).

5. **Safety & emergency features**
   - **SOS button**: on the patient dashboard and in the assistant view
     (patient role only), with a confirmation dialog
     (`components/common/sos-dialog.tsx`). `POST /patients/me/sos`
     immediately creates a caregiver alert that is *never* deduped away,
     unlike routine alerts.
   - **Inactivity nudge**: `alertService.checkInactivity` raises a gentle
     "no activity in 48 hours" alert for caregivers if a patient hasn't
     played a game or completed an activity in 2 days.
   - **Not implemented, on purpose**: GPS/geofencing. It needs real consent
     flows and ongoing location access that felt out of scope for a code
     review pass, and is genuinely privacy-sensitive — worth designing
     deliberately rather than bolting on.

6. **A genuinely smarter assistant, made optional**
   - `server/src/services/llmService.js`: if the operator sets
     `ANTHROPIC_API_KEY` (and `ANTHROPIC_MODEL`) in `server/.env`, the
     assistant grounds real Claude replies in the same live context (profile,
     reminders, today's wellness, most recent game) the rule engine uses,
     in the requester's own language preference. If the key isn't set, or
     the call fails, it falls back to the rule engine automatically — the
     app still works with zero configuration.
   - The rule-based engine itself now has **full Hindi translations** for
     every reply (previously English-only), selected by the requester's own
     `Preferences.language`, plus a new SOS-aware rule. The other 5
     supported UI languages (Assamese, Bodo, Khasi, Mizo, Manipuri) don't
     have assistant translations yet — extending the same
     `isHi(ctx) ? ... : ...` pattern in `assistantService.js` to more
     branches is the way to add them.

## Also fixed while in there
- `.env.example` (backend) and `.env.local.example` (frontend) were
  referenced by both READMEs but missing from the exported project — added
  both, including documentation for every env var the code actually reads.
- The account language preference is now actually synced into the live UI
  across devices: `AppProvider` bridges `preferences.language` into
  `I18nProvider` directly, instead of relying on every call site remembering
  to update both.

## What to do next
- Point `EXPOSE_DEV_RESET_TOKEN` and email delivery at a real provider
  before any real deployment — `services/emailService.js` is the extension
  point.
- If you want the LLM assistant, set `ANTHROPIC_API_KEY` /
  `ANTHROPIC_MODEL` in `server/.env`. Check https://docs.claude.com for
  current model names before choosing one.
- Real push notifications (service worker + VAPID) or SMS (e.g. Twilio)
  would remove the "must keep the tab open" limitation on reminders.
