"use client"

import { useEffect, useState } from "react"
import { Bell, Eye, Languages, Moon, Phone, RotateCcw, Settings2, Shield, Volume2 } from "lucide-react"
import { AppShell } from "@/components/common/app-shell"
import { Card } from "@/components/common/card"
import { useApp } from "@/components/app-provider"
import { useTranslation, LANGUAGES } from "@/lib/i18n"
import { ApiError, getPatientData, updatePatientPhone } from "@/lib/api"
import {
  notificationPermission,
  notificationsSupported,
  requestNotificationPermission,
} from "@/lib/notifications"

export default function SettingsPage() {
  const { preferences, setPreference, role } = useApp()
  const { language, t } = useTranslation()
  const [notifPermission, setNotifPermission] = useState<NotificationPermission | "unsupported">("unsupported")

  useEffect(() => {
    setNotifPermission(notificationPermission())
  }, [])

  const handleNotificationsToggle = async (checked: boolean) => {
    setPreference("notifications", checked)
    // Ask right when the person turns this on — a direct user gesture, which
    // browsers are far more willing to actually show the permission prompt for.
    if (checked && notificationsSupported() && Notification.permission === "default") {
      const result = await requestNotificationPermission()
      setNotifPermission(result)
    }
  }

  return (
    <AppShell title="Settings">
      <div className="flex flex-col gap-6">
        <Card>
          <div className="flex items-start gap-3">
            <span className="flex size-11 items-center justify-center rounded-xl bg-primary/10 text-primary">
              <Settings2 className="size-5" />
            </span>
            <div>
              <h2 className="font-display text-xl font-semibold">Personalise MindCare</h2>
              <p className="mt-1 text-sm text-muted-foreground">
                These settings sync with your MindCare account, so they follow you across devices.
              </p>
            </div>
          </div>

          <div className="mt-6 divide-y divide-border">
            <SettingRow
              icon={<Moon />}
              title="Dark mode"
              description="Use a darker interface in low-light environments."
              control={
                <Toggle
                  checked={preferences.theme === "dark"}
                  label="Toggle dark mode"
                  onChange={(checked) => setPreference("theme", checked ? "dark" : "light")}
                />
              }
            />
            <SettingRow
              icon={<Eye />}
              title="Elder mode"
              description="Larger text and bigger touch targets for easier use."
              control={
                <Toggle
                  checked={preferences.elderMode}
                  label="Toggle elder mode"
                  onChange={(checked) => setPreference("elderMode", checked)}
                />
              }
            />
            <SettingRow
              icon={<Languages />}
              title={t("common.language")}
              description="Choose the language for the login, navigation, and settings screens. This follows your account to every device."
              control={
                <select
                  value={language}
                  onChange={(e) => {
                    // setPreference already drives both the account copy and
                    // the live i18n text — no need to call setLanguage separately.
                    setPreference("language", e.target.value as (typeof LANGUAGES)[number]["code"])
                  }}
                  className="h-11 rounded-lg border border-input bg-card px-3 text-sm outline-none focus:border-primary"
                >
                  {LANGUAGES.map((lang) => (
                    <option key={lang.code} value={lang.code}>
                      {lang.nativeLabel}
                    </option>
                  ))}
                </select>
              }
            />
            <SettingRow
              icon={<Bell />}
              title="Notifications"
              description={
                notifPermission === "unsupported"
                  ? "Your browser doesn't support in-app notifications."
                  : notifPermission === "denied"
                    ? "Blocked in your browser's site settings — enable them there to use this."
                    : "Get a reminder popup (and optional chime) while MindCare is open in this tab."
              }
              control={
                <Toggle
                  checked={preferences.notifications}
                  label="Toggle notifications"
                  onChange={(checked) => void handleNotificationsToggle(checked)}
                />
              }
            />
            <SettingRow
              icon={<Volume2 />}
              title="Sound"
              description="Play a short chime alongside reminder notifications."
              control={
                <Toggle
                  checked={preferences.sound}
                  label="Toggle sound"
                  onChange={(checked) => setPreference("sound", checked)}
                />
              }
            />
          </div>
        </Card>

        {role === "patient" ? (
          <>
            <PhoneCard />

            <Card>
              <div className="flex items-start gap-3">
                <span className="flex size-11 items-center justify-center rounded-xl bg-primary/10 text-primary">
                  <Shield className="size-5" />
                </span>
                <div>
                  <h2 className="font-display text-xl font-semibold">Privacy</h2>
                  <p className="mt-1 text-sm text-muted-foreground">Control what your linked caregiver can see.</p>
                </div>
              </div>
              <div className="mt-6 flex items-center justify-between gap-4 rounded-xl bg-muted/60 p-4">
                <div>
                  <p className="font-medium">{t("privacy.shareToggleLabel")}</p>
                  <p className="mt-1 text-sm text-muted-foreground">{t("privacy.shareToggleHint")}</p>
                </div>
                <Toggle
                  checked={preferences.shareWithCaregiver}
                  label="Toggle sharing activity data with caregiver"
                  onChange={(checked) => setPreference("shareWithCaregiver", checked)}
                />
              </div>
            </Card>
          </>
        ) : null}

        <Card>
          <h2 className="font-display text-lg font-semibold">Motion & text</h2>
          <div className="mt-4 grid gap-3 sm:grid-cols-3">
            {(["normal", "large", "xlarge"] as const).map((scale) => (
              <button
                key={scale}
                type="button"
                onClick={() => setPreference("fontScale", scale)}
                className={`tap-target rounded-xl border-2 px-4 py-4 text-left transition-colors ${
                  preferences.fontScale === scale
                    ? "border-primary bg-primary/8 text-primary"
                    : "border-border hover:border-primary/50"
                }`}
              >
                <span className="block font-semibold capitalize">{scale === "xlarge" ? "Extra large" : scale}</span>
                <span className="mt-1 block text-sm text-muted-foreground">
                  {scale === "normal" ? "Default text" : scale === "large" ? "Comfortable text" : "Maximum readability"}
                </span>
              </button>
            ))}
          </div>

          <div className="mt-4 flex items-center justify-between gap-4 rounded-xl bg-muted/60 p-4">
            <div>
              <p className="font-medium">Reduce motion</p>
              <p className="text-sm text-muted-foreground">Minimise animations and transitions.</p>
            </div>
            <Toggle
              checked={preferences.reduceMotion}
              label="Toggle reduced motion"
              onChange={(checked) => setPreference("reduceMotion", checked)}
            />
          </div>
        </Card>

        <Card>
          <div className="flex items-start gap-3">
            <RotateCcw className="mt-0.5 size-5 text-muted-foreground" />
            <div>
              <h2 className="font-display font-semibold">Connected to MindCare backend</h2>
              <p className="mt-1 text-sm text-muted-foreground">
                Login, games, analytics, assistant and preferences are synced with your account. If the server is
                ever unreachable, the app falls back to your last known data so it keeps working.
              </p>
            </div>
          </div>
        </Card>
      </div>
    </AppShell>
  )
}

/** Lets a patient add a real phone number, so a caregiver's "Call" button on their dashboard dials someone real. */
function PhoneCard() {
  const [value, setValue] = useState("")
  const [status, setStatus] = useState<"idle" | "loading" | "saving" | "saved" | "error">("loading")
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let cancelled = false
    getPatientData()
      .then((data) => {
        if (!cancelled) {
          setValue(data.profile.phone ?? "")
          setStatus("idle")
        }
      })
      .catch(() => {
        if (!cancelled) setStatus("idle")
      })
    return () => {
      cancelled = true
    }
  }, [])

  const save = async () => {
    setStatus("saving")
    setError(null)
    try {
      await updatePatientPhone(value.trim() || null)
      setStatus("saved")
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not save. Please try again.")
      setStatus("error")
    }
  }

  return (
    <Card>
      <div className="flex items-start gap-3">
        <span className="flex size-11 items-center justify-center rounded-xl bg-primary/10 text-primary">
          <Phone className="size-5" />
        </span>
        <div>
          <h2 className="font-display text-xl font-semibold">Contact number</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Shown to your linked caregiver as a one-tap "Call" button on their dashboard.
          </p>
        </div>
      </div>
      <div className="mt-6 flex flex-col gap-3 sm:flex-row">
        <label htmlFor="patient-phone" className="sr-only">
          Phone number
        </label>
        <input
          id="patient-phone"
          type="tel"
          value={value}
          onChange={(e) => {
            setValue(e.target.value)
            setStatus("idle")
          }}
          placeholder="e.g. +91 98765 43210"
          className="h-12 flex-1 rounded-xl border border-input bg-background px-4 text-[15px] outline-none focus-visible:border-primary focus-visible:ring-3 focus-visible:ring-ring/30"
        />
        <button
          type="button"
          onClick={() => void save()}
          disabled={status === "saving" || status === "loading"}
          className="tap-target flex h-12 items-center justify-center rounded-xl bg-primary px-6 font-semibold text-primary-foreground disabled:opacity-60"
        >
          {status === "saving" ? "Saving…" : "Save"}
        </button>
      </div>
      {status === "saved" ? <p className="mt-2 text-sm text-success">Saved.</p> : null}
      {status === "error" ? <p className="mt-2 text-sm text-destructive">{error}</p> : null}
    </Card>
  )
}

function SettingRow({
  icon,
  title,
  description,
  control,
}: {
  icon: React.ReactNode
  title: string
  description: string
  control: React.ReactNode
}) {
  return (
    <div className="flex items-center justify-between gap-5 py-5">
      <div className="flex min-w-0 items-start gap-3">
        <span className="mt-0.5 flex size-10 shrink-0 items-center justify-center rounded-xl bg-muted text-muted-foreground">
          {icon}
        </span>
        <div>
          <p className="font-medium">{title}</p>
          <p className="mt-1 text-sm text-muted-foreground">{description}</p>
        </div>
      </div>
      {control}
    </div>
  )
}

function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (value: boolean) => void; label: string }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      className={`relative h-7 w-12 shrink-0 rounded-full p-1 transition-colors ${
        checked ? "bg-primary" : "bg-muted-foreground/30"
      }`}
    >
      <span
        className={`block size-5 rounded-full bg-white shadow-sm transition-transform ${
          checked ? "translate-x-5" : "translate-x-0"
        }`}
      />
    </button>
  )
}
