import { notFound } from "next/navigation"
import { CardMatchGame } from "@/components/games/card-match-game"
import { PatternRecallGame } from "@/components/games/pattern-recall-game"
import { WordRecallGame } from "@/components/games/word-recall-game"
import { SequenceMemoryGame } from "@/components/games/sequence-memory-game"

export function generateStaticParams() {
  return [
    { gameId: "card-match" },
    { gameId: "pattern-recall" },
    { gameId: "word-recall" },
    { gameId: "sequence-memory" },
  ]
}

export default async function GamePage({ params }: { params: Promise<{ gameId: string }> }) {
  const { gameId } = await params

  if (gameId === "card-match") return <CardMatchGame />
  if (gameId === "pattern-recall") return <PatternRecallGame />
  if (gameId === "word-recall") return <WordRecallGame />
  if (gameId === "sequence-memory") return <SequenceMemoryGame />

  notFound()
}
